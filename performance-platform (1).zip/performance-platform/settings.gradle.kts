rootProject.name = "performance-platform"
